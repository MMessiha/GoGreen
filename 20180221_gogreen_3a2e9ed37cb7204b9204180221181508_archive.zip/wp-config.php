<?php
define('WP_CACHE', false); // Added by WP Rocket


// ** MySQL settings ** //
/** The name of the database for WordPress */
define('DB_NAME', 'go_green170408060218');

/** MySQL database username */
define('DB_USER', '561_media');

/** MySQL database password */
define('DB_PASSWORD', '561_media');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

define('AUTH_KEY',         'iZJA3KV }kHz-(}*N^!d!)~~%gqC<J4(St{(7{^9~6U{|-v9PwbD_Gh@Fq>d|AJO');
define('SECURE_AUTH_KEY',  '^Z[#E5-j@+P}olt_.URaw#?)I$`3Zaa_,KZmc8O_<wBN1#dk9UMcxO`~}0LoR[.>');
define('LOGGED_IN_KEY',    'a-WDcSZgGbT%z Ksb-,qF|hxE G%A>$ViIIbr5vF=T4/..X+C|(Ydyv8g6Pi!9@8');
define('NONCE_KEY',        'N;|?xR9V[(ii}pezIf%+NYD;{IvQ7D=yo,gXhx#y-xT;C*xzCSL>O3(L/*UZv;9_');
define('AUTH_SALT',        'H+A{EhpA|]+_L-wA%h%+XN*)aX-i+TJIA3BF-&>_WX6<i%<,J6lDJ`?EZ=Pe&H+ ');
define('SECURE_AUTH_SALT', '9h*RQkqL#,[}=2M)IbDP7}k<|k.0%[gJ|/]5O=7A&[{SD1(GT8)wme+F+_NEtS3S');
define('LOGGED_IN_SALT',   '|!r 5N0(K7g>`|&~LZHJM`dMVM-={CH>00AP:s]L>Dy5J:|P4dB/PY3?fFvQJ16d');
define('NONCE_SALT',       '_3zg+=VU0n`NBZ9Md]Vcq;dMV+IyhF)zxhegAAsuhWr/bn1[]3D~f,{ZT$o31| a');


$table_prefix = 'wp_';





define('ALLOW_UNFILTERED_UPLOADS', true);
define('WP_MEMORY_LIMIT','64M');
define('WP_DEBUG', true);
/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
define('FS_METHOD','direct');
